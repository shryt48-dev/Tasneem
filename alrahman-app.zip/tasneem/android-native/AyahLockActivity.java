package com.tasneem.athkar;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * آية تظهر فوق أي تطبيق (حتى فوق شاشة القفل) كل ما يفتح المستخدم هاتفه —
 * تُقرأ، يُضغط "قرأتها"، فتُسجَّل وتختفي فورًا لتعود الشاشة اللي كانت ظاهرة قبلها.
 * تشترك في نفس مؤشر الآية مع ودجت الشاشة الرئيسية عشان التقدّم يفضل متسق.
 */
public class AyahLockActivity extends Activity {

    private static final String KEY_INDEX = "widgetAyahIndex";
    private static List<Ay> ALL;

    static class Ay {
        int surah, numInSurah, juz;
        String text, surahName;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindowOverLock();

        List<Ay> all = load(this);
        SharedPreferences p = getSharedPreferences(DhikrService.PREFS, MODE_PRIVATE);
        int idx = all.isEmpty() ? 0 : (((p.getInt(KEY_INDEX, 0) % all.size()) + all.size()) % all.size());
        Ay a = all.isEmpty() ? null : all.get(idx);

        setContentView(buildView(a));
    }

    private void setupWindowOverLock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    }

    private View buildView(final Ay a) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0B211B"));
        int pad = dp(28);
        root.setPadding(pad, pad, pad, pad);

        TextView eyebrow = new TextView(this);
        eyebrow.setText("آيتك الآن");
        eyebrow.setTextColor(Color.parseColor("#E4C86B"));
        eyebrow.setTextSize(13);
        eyebrow.setGravity(Gravity.CENTER);
        root.addView(eyebrow);

        TextView locView = new TextView(this);
        TextView txt = new TextView(this);
        txt.setTextColor(Color.parseColor("#F6EEDC"));
        txt.setTextSize(24);
        txt.setGravity(Gravity.CENTER);
        txt.setLineSpacing(dp(6), 1f);
        LinearLayout.LayoutParams txtLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        txtLp.topMargin = dp(18); txtLp.bottomMargin = dp(14);

        if (a != null) {
            txt.setText(a.text);
            locView.setText("سورة " + a.surahName + " — آية " + a.numInSurah + " — الجزء " + a.juz);
        } else {
            txt.setText("افتح الرحمن مرة واحدة وأنت متصل بالإنترنت لتحميل المصحف");
            locView.setText("");
        }
        locView.setTextColor(Color.parseColor("#8AA9A0"));
        locView.setTextSize(12.5f);
        locView.setGravity(Gravity.CENTER);

        root.addView(txt, txtLp);
        root.addView(locView);

        Button check = new Button(this);
        check.setText("✓ قرأتها");
        check.setTextColor(Color.parseColor("#0B211B"));
        check.setBackgroundColor(Color.parseColor("#E4C86B"));
        check.setAllCaps(false);
        check.setTextSize(16);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        btnLp.topMargin = dp(30);
        check.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { markReadAndClose(a); }
        });
        root.addView(check, btnLp);

        TextView skip = new TextView(this);
        skip.setText("لاحقًا");
        skip.setTextColor(Color.parseColor("#8AA9A0"));
        skip.setTextSize(13);
        skip.setGravity(Gravity.CENTER);
        skip.setPadding(0, dp(16), 0, 0);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        root.addView(skip);

        return root;
    }

    private void markReadAndClose(Ay a) {
        SharedPreferences p = getSharedPreferences(DhikrService.PREFS, MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit();
        e.putInt(KEY_INDEX, p.getInt(KEY_INDEX, 0) + 1);
        e.putInt("pendingGateRead", p.getInt("pendingGateRead", 0) + 1);
        if (a != null) {
            int len = a.text == null ? 0 : a.text.replaceAll("\\s+", "").length();
            e.putInt("pendingGateChars", p.getInt("pendingGateChars", 0) + len);
        }
        e.apply();
        try { AyahWidgetProvider.pushUpdatePublic(this); } catch (Exception ignored) {}
        finish();
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }

    private static synchronized List<Ay> load(android.content.Context ctx) {
        if (ALL != null) return ALL;
        List<Ay> list = new ArrayList<>();
        try {
            InputStream is = ctx.getAssets().open("quran.json");
            BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            JSONObject root = new JSONObject(sb.toString());
            JSONArray surahs = root.getJSONObject("data").getJSONArray("surahs");
            for (int i = 0; i < surahs.length(); i++) {
                JSONObject s = surahs.getJSONObject(i);
                String sName = s.getString("name");
                int sNumber = s.getInt("number");
                JSONArray ayahs = s.getJSONArray("ayahs");
                for (int j = 0; j < ayahs.length(); j++) {
                    JSONObject a = ayahs.getJSONObject(j);
                    Ay ay = new Ay();
                    ay.surah = sNumber;
                    ay.surahName = sName;
                    ay.numInSurah = a.getInt("numberInSurah");
                    ay.juz = a.getInt("juz");
                    ay.text = a.getString("text");
                    list.add(ay);
                }
            }
        } catch (Exception ignored) {
            // مفيش نسخة مصحف داخل التطبيق بعد — هيظهر نص توجيهي بدل الآية
        }
        ALL = list;
        return ALL;
    }
}
