package com.tasneem.athkar;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.HashMap;
import java.util.Locale;
import androidx.core.app.NotificationCompat;

/**
 * يستقبل منبّه وقت الصلاة، يرفع إشعارًا بأهمية عالية ويشغّل الأذان كاملًا.
 * يُجدوَل من TasneemPlugin عبر AlarmManager.setExactAndAllowWhileIdle.
 */
public class AdhanReceiver extends BroadcastReceiver {

    public static final String CH_ADHAN = "tasneem_adhan";

    @Override public void onReceive(Context ctx, Intent intent) {
        String prayer = intent.getStringExtra("prayer");
        if (prayer == null) prayer = "الصلاة";

        SharedPreferences p = ctx.getSharedPreferences(DhikrService.PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("adhanEnabled", true)) return;

        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "tasneem:adhan");
        wl.acquire(3 * 60 * 1000L);

        createChannel(ctx);
        Intent open = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        PendingIntent pi = PendingIntent.getActivity(ctx, 7001, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new NotificationCompat.Builder(ctx, CH_ADHAN)
                .setContentTitle("حان الآن موعد أذان " + prayer)
                .setContentText("اللهم صلِّ وسلّم على نبينا محمد")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(7001, n);

        // تشغيل الأذان: ضع الملف في res/raw/adhan.mp3 (وres/raw/adhan_fajr.mp3 لأذان الفجر)
        try {
            String name = prayer.contains("الفجر") ? "adhan_fajr" : "adhan";
            int resId = ctx.getResources().getIdentifier(name, "raw", ctx.getPackageName());
            if (resId == 0) resId = ctx.getResources().getIdentifier("adhan", "raw", ctx.getPackageName());
            if (resId != 0) {
                MediaPlayer mp = MediaPlayer.create(ctx, resId);
                if (mp != null) {
                    mp.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    mp.setOnCompletionListener(m -> m.release());
                    mp.start();
                }
                if (wl.isHeld()) wl.release();
            } else {
                // مفيش ملف أذان مضاف يدويًا — إعلان صوتي تلقائي بدون أي إعداد من المستخدم
                announceAdhan(ctx, prayer, wl);
            }
        } catch (Exception ignored) { if (wl.isHeld()) wl.release(); }

        // إعادة جدولة اليوم التالي يتولاها التطبيق عند فتحه، ونجدول احتياطيًا بعد 24 ساعة
        TasneemPlugin.rescheduleNextDay(ctx, prayer, intent.getLongExtra("at", 0));
    }

    /* إعلان صوتي بديل عند عدم توفر ملف أذان — يحرّر الـ wake lock بعد انتهاء النطق أو خلال ٢٥ ثانية كحد أقصى */
    private void announceAdhan(Context ctx, String prayer, PowerManager.WakeLock wl) {
        final TextToSpeech[] holder = new TextToSpeech[1];
        final boolean[] released = { false };
        Runnable release = () -> {
            synchronized (released) {
                if (released[0]) return;
                released[0] = true;
            }
            try { if (holder[0] != null) { holder[0].stop(); holder[0].shutdown(); } } catch (Exception ignored) {}
            if (wl.isHeld()) wl.release();
        };
        Handler safety = new Handler(Looper.getMainLooper());
        safety.postDelayed(release, 25_000L);

        holder[0] = new TextToSpeech(ctx, status -> {
            if (status != TextToSpeech.SUCCESS) { release.run(); return; }
            holder[0].setLanguage(new Locale("ar"));
            holder[0].setSpeechRate(0.85f);
            holder[0].setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) { release.run(); }
                @Override public void onError(String id) { release.run(); }
            });
            HashMap<String, String> params = new HashMap<>();
            params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "adhan");
            holder[0].speak("الله أكبر، الله أكبر، حان الآن موعد أذان " + prayer,
                    TextToSpeech.QUEUE_FLUSH, params);
        });
    }

    private void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH_ADHAN, "الأذان",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("تنبيه دخول وقت الصلاة");
        ch.enableVibration(true);
        ch.setSound(null, null);   // الصوت بنشغّله بأنفسنا عشان الأذان أطول من 30 ثانية
        nm.createNotificationChannel(ch);
    }
}
