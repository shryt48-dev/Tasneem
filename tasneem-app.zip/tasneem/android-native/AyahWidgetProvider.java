package com.tasneem.athkar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * ودجت "آية اليوم" على الشاشة الرئيسية للهاتف — يعمل بدون فتح التطبيق.
 * يتقدّم تلقائيًا لآية جديدة كل مرة يُفتح فيها قفل الهاتف (نفس مُستقبِل DhikrService)،
 * وفيه أزرار للتنقل يدويًا وتشغيل التلاوة.
 */
public class AyahWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_NEXT = "com.tasneem.athkar.WIDGET_NEXT";
    public static final String ACTION_PREV = "com.tasneem.athkar.WIDGET_PREV";
    public static final String ACTION_PLAY = "com.tasneem.athkar.WIDGET_PLAY";
    private static final String KEY_INDEX = "widgetAyahIndex";

    static class Ayah {
        int surah, numInSurah, juz;
        String text, surahName;
    }

    private static List<Ayah> ALL;   // يُحمَّل مرة واحدة لكل عملية تشغيل

    private static synchronized List<Ayah> data(Context ctx) {
        if (ALL != null) return ALL;
        List<Ayah> list = new ArrayList<>();
        try {
            InputStream is = ctx.getAssets().open("quran.json");
            BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            JSONObject root = new JSONObject(sb.toString());
            JSONArray surahs = root.getJSONObject("data").getJSONArray("surahs");
            for (int i = 0; i < surahs.length(); i++) {
                JSONObject s = surahs.getJSONObject(i);
                String sName = s.getString("name");
                int sNumber = s.getInt("number");
                JSONArray ayahs = s.getJSONArray("ayahs");
                for (int j = 0; j < ayahs.length(); j++) {
                    JSONObject a = ayahs.getJSONObject(j);
                    Ayah ay = new Ayah();
                    ay.surah = sNumber;
                    ay.surahName = sName;
                    ay.numInSurah = a.getInt("numberInSurah");
                    ay.juz = a.getInt("juz");
                    ay.text = a.getString("text");
                    list.add(ay);
                }
            }
        } catch (Exception ignored) {
            // مفيش ملف مصحف داخل التطبيق — الودجت هيعرض رسالة توجيهية بدل الآية
        }
        ALL = list;
        return ALL;
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(DhikrService.PREFS, Context.MODE_PRIVATE);
    }

    private static int currentIndex(Context ctx, int total) {
        if (total <= 0) return 0;
        int i = prefs(ctx).getInt(KEY_INDEX, 0);
        return ((i % total) + total) % total;
    }

    /** يستدعيها UnlockReceiver داخل DhikrService عند كل فتح لقفل الهاتف. */
    public static void advanceAndUpdateAll(Context ctx) {
        List<Ayah> all = data(ctx);
        if (!all.isEmpty()) {
            int i = currentIndex(ctx, all.size());
            prefs(ctx).edit().putInt(KEY_INDEX, (i + 1) % all.size()).apply();
        }
        pushUpdatePublic(ctx);
    }

    public static void pushUpdatePublic(Context ctx) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, AyahWidgetProvider.class));
            for (int id : ids) updateOne(ctx, mgr, id);
        } catch (Exception ignored) {}
    }

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) updateOne(ctx, mgr, id);
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        String action = intent.getAction();
        if (action == null) return;
        List<Ayah> all = data(ctx);
        if (all.isEmpty()) return;

        if (ACTION_NEXT.equals(action)) {
            int i = currentIndex(ctx, all.size());
            prefs(ctx).edit().putInt(KEY_INDEX, (i + 1) % all.size()).apply();
            pushUpdatePublic(ctx);
        } else if (ACTION_PREV.equals(action)) {
            int i = currentIndex(ctx, all.size());
            prefs(ctx).edit().putInt(KEY_INDEX, (i - 1 + all.size()) % all.size()).apply();
            pushUpdatePublic(ctx);
        } else if (ACTION_PLAY.equals(action)) {
            Ayah a = all.get(currentIndex(ctx, all.size()));
            Intent svc = new Intent(ctx, WidgetPlayService.class);
            svc.putExtra("surah", a.surah);
            svc.putExtra("ayah", a.numInSurah);
            try { ctx.startService(svc); } catch (Exception ignored) {}
        }
    }

    private static void updateOne(Context ctx, AppWidgetManager mgr, int widgetId) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_ayah);
        List<Ayah> all = data(ctx);

        if (all.isEmpty()) {
            v.setTextViewText(R.id.widget_ayah_text,
                    "افتح تسنيم مرة واحدة وأنت متصل بالإنترنت — بعدها يشتغل الودجت بدون نت.");
            v.setTextViewText(R.id.widget_location, "");
            v.setTextViewText(R.id.widget_juz, "");
        } else {
            Ayah a = all.get(currentIndex(ctx, all.size()));
            v.setTextViewText(R.id.widget_ayah_text, a.text);
            v.setTextViewText(R.id.widget_location, "سورة " + a.surahName + " — آية " + a.numInSurah);
            v.setTextViewText(R.id.widget_juz, "الجزء " + a.juz);
        }

        v.setOnClickPendingIntent(R.id.widget_btn_next, actionIntent(ctx, ACTION_NEXT, widgetId));
        v.setOnClickPendingIntent(R.id.widget_btn_prev, actionIntent(ctx, ACTION_PREV, widgetId));
        v.setOnClickPendingIntent(R.id.widget_btn_play, actionIntent(ctx, ACTION_PLAY, widgetId));

        try {
            Intent open = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (open != null) {
                PendingIntent openPi = PendingIntent.getActivity(ctx, 9000, open,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                v.setOnClickPendingIntent(R.id.widget_root, openPi);
            }
        } catch (Exception ignored) {}

        mgr.updateAppWidget(widgetId, v);
    }

    private static PendingIntent actionIntent(Context ctx, String action, int widgetId) {
        Intent i = new Intent(ctx, AyahWidgetProvider.class);
        i.setAction(action);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        return PendingIntent.getBroadcast(ctx, (action + widgetId).hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
