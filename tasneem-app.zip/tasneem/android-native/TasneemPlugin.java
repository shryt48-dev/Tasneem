package com.tasneem.athkar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import androidx.core.content.FileProvider;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * الجسر بين واجهة التطبيق (JS) وخدمات أندرويد.
 *
 * من جافاسكريبت:
 *   const { Tasneem } = Capacitor.Plugins;
 *   await Tasneem.start();
 *   await Tasneem.setConfig({ unlockEnabled:true, cooldownMin:30, soundEnabled:true,
 *                          periodicEnabled:true, periodicMin:60, adhanEnabled:true });
 *   await Tasneem.scheduleAdhan({ times:[{name:'الفجر', at: 1767...}, ...] });
 *   const { salawat } = await Tasneem.pullCounts();   // يرجّع العدد المتراكم ويصفّره
 */
@CapacitorPlugin(name = "Tasneem")
public class TasneemPlugin extends Plugin {

    @PluginMethod
    public void start(PluginCall call) {
        Context ctx = getContext();
        Intent svc = new Intent(ctx, DhikrService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(svc);
        else ctx.startService(svc);
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().stopService(new Intent(getContext(), DhikrService.class));
        call.resolve();
    }

    @PluginMethod
    public void setConfig(PluginCall call) {
        SharedPreferences.Editor e = prefs().edit();
        if (call.hasOption("unlockEnabled"))   e.putBoolean("unlockEnabled", call.getBoolean("unlockEnabled", true));
        if (call.hasOption("soundEnabled"))    e.putBoolean("soundEnabled", call.getBoolean("soundEnabled", true));
        if (call.hasOption("periodicEnabled")) e.putBoolean("periodicEnabled", call.getBoolean("periodicEnabled", true));
        if (call.hasOption("adhanEnabled"))    e.putBoolean("adhanEnabled", call.getBoolean("adhanEnabled", true));
        if (call.hasOption("cooldownMin"))     e.putInt("cooldownMin", call.getInt("cooldownMin", 30));
        if (call.hasOption("periodicMin"))     e.putInt("periodicMin", call.getInt("periodicMin", 60));
        if (call.hasOption("reciter"))         e.putString("reciter", call.getString("reciter", "yasser"));
        e.apply();
        call.resolve();
    }

    @PluginMethod
    public void refreshWidget(PluginCall call) {
        AyahWidgetProvider.pushUpdatePublic(getContext());
        call.resolve();
    }

    /**
     * يشارك ملف التطبيق (APK) نفسه عبر أي تطبيق تاني (واتساب، بلوتوث...) —
     * ينسخه أولًا لمجلد الكاش الخاص بالتطبيق (المكان الوحيد اللي FileProvider يقدر يعرضه)
     * ثم يفتح نافذة المشاركة القياسية في أندرويد بيها الملف الحقيقي جاهز للإرسال.
     */
    @PluginMethod
    public void shareApk(PluginCall call) {
        Context ctx = getContext();
        try {
            String srcPath = ctx.getPackageManager().getApplicationInfo(ctx.getPackageName(), 0).sourceDir;
            File src = new File(srcPath);
            File dst = new File(ctx.getCacheDir(), "تسنيم.apk");
            if (!dst.exists() || dst.length() != src.length()) {
                try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
            }
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", dst);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/vnd.android.package-archive");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "تسنيم — المصحف والأذكار ومواقيت الصلاة");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(share, "شارك تطبيق تسنيم");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("تعذّرت المشاركة: " + e.getMessage());
        }
    }

    /**
     * يطلب من نظام أندرويد عرض نافذة "إضافة الودجت للشاشة الرئيسية؟" تلقائيًا —
     * بضغطة واحدة بدل ما يفتح المستخدم قائمة الودجات يدويًا ويدوّر على التطبيق.
     * مدعومة من أندرويد 8 فأعلى ومعظم لانشرات الشاشة الرئيسية (سامسونج One UI منها).
     */
    @PluginMethod
    public void requestPinWidget(PluginCall call) {
        Context ctx = getContext();
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                call.resolve(new JSObject().put("supported", false));
                return;
            }
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            ComponentName provider = new ComponentName(ctx, AyahWidgetProvider.class);
            boolean supported = mgr.isRequestPinAppWidgetSupported();
            if (supported) {
                mgr.requestPinAppWidget(provider, null, null);
            }
            call.resolve(new JSObject().put("supported", supported));
        } catch (Exception e) {
            call.resolve(new JSObject().put("supported", false));
        }
    }

    @PluginMethod
    public void pullCounts(PluginCall call) {
        int s = prefs().getInt("pendingSalawat", 0);
        int gr = prefs().getInt("pendingGateRead", 0);
        int gc = prefs().getInt("pendingGateChars", 0);
        prefs().edit()
                .putInt("pendingSalawat", 0)
                .putInt("pendingGateRead", 0)
                .putInt("pendingGateChars", 0)
                .apply();
        JSObject r = new JSObject();
        r.put("salawat", s);
        r.put("gateRead", gr);
        r.put("gateChars", gc);
        call.resolve(r);
    }

    @PluginMethod
    public void scheduleAdhan(PluginCall call) {
        Context ctx = getContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        JSArray times = call.getArray("times");
        if (times == null) { call.reject("times مطلوبة"); return; }

        // إلغاء القديم
        for (int i = 0; i < 40; i++) {
            PendingIntent old = PendingIntent.getBroadcast(ctx, 8000 + i,
                    new Intent(ctx, AdhanReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) am.cancel(old);
        }

        try {
            for (int i = 0; i < times.length() && i < 40; i++) {
                JSONObject o = (JSONObject) times.get(i);
                long at = o.getLong("at");
                if (at <= System.currentTimeMillis()) continue;
                Intent in = new Intent(ctx, AdhanReceiver.class);
                in.putExtra("prayer", o.getString("name"));
                in.putExtra("at", at);
                PendingIntent pi = PendingIntent.getBroadcast(ctx, 8000 + i, in,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
                }
            }
            call.resolve();
        } catch (Exception ex) {
            call.reject(ex.getMessage());
        }
    }

    /** جدولة احتياطية بعد ٢٤ ساعة لو المستخدم مفتحش التطبيق. */
    static void rescheduleNextDay(Context ctx, String prayer, long at) {
        if (at <= 0) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(ctx, AdhanReceiver.class);
        in.putExtra("prayer", prayer);
        in.putExtra("at", at + 86_400_000L);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 8500 + Math.abs(prayer.hashCode() % 100), in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at + 86_400_000L, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at + 86_400_000L, pi);
            }
        } catch (SecurityException ignored) { }
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(DhikrService.PREFS, Context.MODE_PRIVATE);
    }
}
